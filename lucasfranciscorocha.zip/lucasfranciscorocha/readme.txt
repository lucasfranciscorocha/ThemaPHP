=== Lucas Francisco Rocha ===
Contributors: Lucas Francisco Rocha
Requires at least: 6.0
Tested up to: 6.4.3
Requires PHP: 5.7
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==



== Changelog ==

= 1.0.0 =
* Initial release

== Copyright ==

Lucas Francisco Rocha is a child theme of Personal Help Desk (https://github.com/lucasfranciscorocha), (C) Lucas Francisco Rocha, [GPLv2 or later](http://www.gnu.org/licenses/gpl-2.0.html)

Personal Help Desk WordPress Theme, (C) 2024 Lucas Francisco Rocha
Personal Help Desk is distributed under the terms of the GNU GPL.

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

Dream Orphans Font
Copyright (c) Ray Larabie, 2000. All rights reserved. 
  
-- End of Dream Orphans Font credits --

Romande ADF Script Std Font
Copyright (c) Arkandis Digital Foundry under the GNU General Public License V2 and later with font exception. 
The use of this font is granted subject to the GNU General Public License V2 and later with font exception. 
License URL: http://www.gnu.org/copyleft/gpl.html 
Source: http://arkandis.tuxfamily.org
-- End of Romande ADF Script Std Font credits --

